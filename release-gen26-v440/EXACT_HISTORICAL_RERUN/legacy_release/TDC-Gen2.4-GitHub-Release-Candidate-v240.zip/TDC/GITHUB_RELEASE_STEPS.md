# GitHub Release Steps

```bash
git init
git add .
git commit -m "TDC Gen2.4 frozen experimental release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/TDC.git
git push -u origin main

git tag -a v0.2.0-gen2.4 -m "TDC Gen2.4 frozen experimental release"
git push origin v0.2.0-gen2.4
```

Then create a GitHub Release from tag `v0.2.0-gen2.4` and paste the contents of
`RELEASE_NOTES_v0.2.0-gen2.4.md`.

Future architecture work should start from a new branch:

```bash
git checkout -b research/gen2.5
```
