---
name: Experiment proposal
about: Propose a falsifiable TDC experiment
title: "[EXPERIMENT] "
labels: experiment
---

## Claim under test

## Strongest baseline

## Frozen metrics

## Dataset/environment

## Holdout strategy

## Failure criterion

## Leakage checks

## Expected result (before running)
