---
name: Bug report
about: Report implementation or reproducibility problems
title: "[BUG] "
labels: bug
---

## Reproduction steps

## Expected behavior

## Actual behavior

## Environment

## Does this affect a frozen result?
