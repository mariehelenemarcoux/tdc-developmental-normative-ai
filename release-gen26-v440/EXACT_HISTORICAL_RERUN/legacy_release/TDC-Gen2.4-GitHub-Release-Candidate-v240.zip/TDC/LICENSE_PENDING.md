# License not yet selected

A software license has intentionally not been added automatically.

Before publishing this repository, choose the license that matches your goals.
Common options include MIT and Apache-2.0.

Do not publish publicly without considering the consequences of the license
choice for reuse, redistribution, patents, and derivative work.
