# Publishing TDC to GitHub — step by step

## 1. Unzip the package

Extract the ZIP into the folder where you want the repository to live.

## 2. Choose the repository name

Recommended:
- `TDC`
- `TDC-Gen2`
- `tdc-positive-disintegration`

Suggested description:

> Developmental normative AI architecture inspired by Dąbrowski's Theory of Positive Disintegration.

## 3. Choose a license before going public

This package intentionally does **not** choose a license for you.

On GitHub, when creating the repository, you can choose:
- **MIT** — very permissive;
- **Apache-2.0** — permissive + explicit patent grant;
- another license appropriate to your goals.

If you are unsure about legal implications, keep the repository private until you decide.

## 4. Test locally

From the repository root:

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
pytest -q
```

macOS/Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

## 5. Initialize Git locally

```bash
git init
git add .
git commit -m "Initial release: TDC Gen2.3"
```

## 6. Create the GitHub repository

On GitHub:
1. Click **New repository**.
2. Name it `TDC` (recommended).
3. Add the description above.
4. Choose **Public** or **Private**.
5. Do **not** initialize with another README if you want to upload this folder as-is.
6. Add your chosen license if desired.

## 7. Connect the local folder

Replace `YOUR_USERNAME`:

```bash
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/TDC.git
git push -u origin main
```

## 8. Verify the repository

Check that GitHub shows:
- `README.md`
- `src/tdc/gen23.py`
- `docs/THEORY.md`
- `docs/EXPERIMENTAL_HISTORY.md`
- `docs/LIMITATIONS.md`
- `results/v231_frozen_holdout/`
- `requirements.txt`
- `pyproject.toml`

## 9. Create the first release

Recommended tag:

```text
v0.1.0-gen2.3
```

Recommended release title:

```text
TDC Gen2.3 — Frozen Experimental Release
```

Recommended release note:

> First frozen experimental release of TDC Gen2.3. Includes the adaptive Third Factor controller frozen in v230 and evaluated without parameter changes in the v231 held-out synthetic benchmark. Results should be interpreted as internal synthetic evidence only.

## 10. Pin the scientific boundaries

Keep the non-claims visible in the README. Do not describe the current results as evidence of:
- literal Dąbrowskian Level V;
- intrinsic ethics;
- thermodynamic negentropy;
- general real-world superiority.

Use terms such as:
- “functional analogue”;
- “synthetic benchmark”;
- “developmental normative architecture”;
- “Dąbrowski-inspired”.

## 11. Recommended next research milestone

Do **not** tune v231 after publication.

The next branch/version should target an external benchmark or environment and be versioned separately, for example:

```text
research/external-validation
```

Keep Gen2.3 frozen so later results remain auditable.
